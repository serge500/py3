import time
# <yes> <report> PYTHON_DOS 7be7e0
time.sleep(delay)
# <no> <report>
time.sleep(10)