from http.cookies import SimpleCookie
from WebKit.HTTPResponse import HTTPResponse
from django.conf import settings

response = HTTPResponse()
cookie = SimpleCookie()
cookie['foo'] = 'bar'

# <yes> <report> PYTHON_COOKIE_NOT_OVER_SSL 2a61c4
cookie['foo']['secure'] = notSoSure

# <no> <report>
cookie['foo']['secure'] = True

# <yes> <report> PYTHON_COOKIE_NOT_OVER_SSL 1lf1c4
CSRF_COOKIE_SECURE = False

# <yes> <report> PYTHON_COOKIE_NOT_OVER_SSL 1er1c4
settings.configure(SESSION_COOKIE_SECURE=False)

