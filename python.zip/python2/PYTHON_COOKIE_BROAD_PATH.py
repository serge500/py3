from http.cookies import SimpleCookie
from django.http.response import HttpResponse
from django.conf import settings
from WebKit.HTTPResponse import HTTPResponse
'''
# FIXME: does not detect class in this case:
from http import cookies
cookie = cookies.SimpleCookie()
'''

response = HTTPResponse()
cookie = SimpleCookie()

# <yes> <report> PYTHON_COOKIE_BROAD_PATH b49cc1
cookie['foo']['path'] = '/'

# <yes> <report> PYTHON_COOKIE_BROAD_PATH fhy233
response.setCookie(name, value, path='/', expires='ONCLOSE', secure=False)

# <yes> <report> PYTHON_COOKIE_BROAD_PATH fhy233
response.setCookie(name, value, '/', expires='ONCLOSE', secure=False)

# <yes> <report> PYTHON_COOKIE_BROAD_PATH 3lf1c4
SESSION_COOKIE_PATH = "/"

# <yes> <report> PYTHON_COOKIE_BROAD_PATH 3er1c4
settings.configure(CSRF_COOKIE_PATH="/")


def method5(request):
    res = HttpResponse()
    # <yes> <report> PYTHON_COOKIE_BROAD_PATH 3er1c5
    res.set_cookie("emailCookie", email, secure=True, httponly=True, path='/')
    return res

