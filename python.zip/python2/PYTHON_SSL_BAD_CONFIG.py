import ssl
# <yes> <report> PYTHON_SSL_BAD_CONFIG 2esqb0
ssl.PROTOCOL_TLSv1_3
# <yes> <report> PYTHON_SSL_BAD_CONFIG revqb5
ssl_version = ssl.PROTOCOL_SSLv23

#fake
# <no> <report> PYTHON_SSL_BAD_CONFIG revqb8,revqb5
s = ssl.wrap_socket(sock, do_handshake_on_connect=True,
                    server_side=True, certfile=self.certificate,
                    keyfile=self.private_key, ssl_version=ssl.PROTOCOL_TLSv1_2)
 
context = ssl.create_default_context()

#fake
# <no> <report> PYTHON_SSL_BAD_CONFIG 0eswb4
context.options &= ~ssl.OP_NO_SSLv2
#fake
# <no> <report> PYTHON_SSL_BAD_CONFIG 0eswb4
context.options &= ~ssl.OP_NO_SSLv3

# https://www.quantifiedcode.com/knowledge-base/security/%60SECURE_PROXY_SSL_HEADER%60%20set/70VXf68D
# <yes> <report> PYTHON_SSL_BAD_CONFIG ruuq99
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
#fake
# <no> <report>
SECURE_PROXY_SSL_HEADER = None

# <yes> <report> PYTHON_SSL_BAD_CONFIG revqb9
def open_ssl_socket(version=ssl.PROTOCOL_SSLv2):
    pass

# <yes> <report> PYTHON_SSL_BAD_CONFIG revqb7
ssl.wrap_socket()
# <yes> <report> PYTHON_SSL_BAD_CONFIG 2esq10
ssl.PROTOCOL_TLS
# <yes> <report> PYTHON_SSL_BAD_CONFIG revq10
ssl_version = ssl.PROTOCOL_TLS
s = ssl.wrap_socket(sock, do_handshake_on_connect=True,
                    server_side=True, certfile=self.certificate,
# <yes> <report> PYTHON_SSL_BAD_CONFIG revq10
                    keyfile=self.private_key, ssl_version=ssl.PROTOCOL_TLS)
