from web3.eth import signTransaction, sendRawTransaction

# <yes> <report> PYTHON_WEB3_HARDCODED_PRIVATE_KEY s5fgh7
signed = w3.eth.signTransaction(transaction, 'hardcoded_private_key')
# <yes> <report> PYTHON_WEB3_HARDCODED_PRIVATE_KEY s5fgh7
signed_txn = w3.eth.signTransaction(transaction, private_key='hardcoded_private_key')
# <yes> <report> PYTHON_WEB3_HARDCODED_PRIVATE_KEY s5fgh7
signed = signTransaction(transaction, 'hardcoded_private_key')
# <yes> <report> PYTHON_WEB3_HARDCODED_PRIVATE_KEY s5fgh7
signed_txn = signTransaction(transaction, private_key='hardcoded_private_key')

pk = 'hardcoded_private_key'

if 5 == 5:
    # <yes> <report> PYTHON_WEB3_HARDCODED_PRIVATE_KEY a334hy
    signed = w3.eth.signTransaction(transaction, pk)
    # <yes> <report> PYTHON_WEB3_HARDCODED_PRIVATE_KEY a334hy
    signed_txn = w3.eth.signTransaction(transaction, private_key=pk)
    # <yes> <report> PYTHON_WEB3_HARDCODED_PRIVATE_KEY a334hy
    signed = signTransaction(transaction, pk)
    # <yes> <report> PYTHON_WEB3_HARDCODED_PRIVATE_KEY a334hy
    signed_txn = signTransaction(transaction, private_key=pk)
