import web3
from web3.contract import ConciseContract, ImplicitContract

# <yes> <report> PYTHON_WEB3_DEPRECATED_CLASS df8nb4
concise = ConciseContract(myContract)
# <yes> <report> PYTHON_WEB3_DEPRECATED_CLASS df8nb4
concise = ImplicitContract(myContract)

# <yes> <report> PYTHON_WEB3_DEPRECATED_CLASS df8nb4
concise = web3.contract.ConciseContract(myContract)
# <yes> <report> PYTHON_WEB3_DEPRECATED_CLASS df8nb4
concise = web3.contract.ImplicitContract(myContract)
