from web3.eth import getTransactionCount
# <yes> <report> PYTHON_WEB3_DEPRECATED_METHOD fb6ikk
myContract.deploy()
