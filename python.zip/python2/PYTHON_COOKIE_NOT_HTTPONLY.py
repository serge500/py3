from http.cookies import SimpleCookie
from django.conf import settings
import django.http as http


cookie = SimpleCookie()
cookie['foo'] = 'bar'

# <yes> <report> PYTHON_COOKIE_NOT_HTTPONLY d6d76e
cookie['foo']['httponly'] = notSoSure
# <no> <report>
cookie['foo']['httponly'] = True

# Содержимое settings.py библиотеки Django
# <yes> <report> PYTHON_COOKIE_NOT_HTTPONLY 2lf1c4
SESSION_COOKIE_HTTPONLY = False

# <yes> <report> PYTHON_COOKIE_NOT_HTTPONLY ler1c4
settings.configure(SESSION_COOKIE_HTTPONLY=False)

# <yes> <report> PYTHON_COOKIE_NOT_HTTPONLY ler1c4
settings.configure(CSRF_COOKIE_HTTPONLY=False)


def method2(request):
    goto = request.GET.get('goto', '')
    response = http.HttpResponseRedirect(goto)

    # <yes> <report> PYTHON_COOKIE_NOT_HTTPONLY ler1c5
    response.set_cookie('PIZZA_EDIT',
                        value='ON',
                        max_age=100,
                        httponly=False,
                        path='/path')
    return response
