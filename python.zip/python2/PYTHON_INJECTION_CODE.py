# <yes> <report> PYTHON_INJECTION_CODE exec34
exec("do evil")
