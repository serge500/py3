import os

# <no> <report> PYTHON_FILE_PERMISSIONS wq28d3 - ToDo перенести в xml-matcher
# chmod: CommandFilter, chmod, root

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod2 <yes> <report> PYTHON_FILE_SEPARATOR_HARDCODED 9528cd
os.chmod('/etc/hosts', 0o777)

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod4 <yes> <report> PYTHON_FILE_SEPARATOR_HARDCODED 9528cd
os.chmod('/etc/hosts', stat.S_IRWXO)

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod1 <yes> <report> PYTHON_FILE_SEPARATOR_HARDCODED 9528cd
os.chmod('/etc/passwd', stat.S_IXOTH)

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod1 <yes> <report> PYTHON_FILE_SEPARATOR_HARDCODED 9528cd
os.chmod('/etc/passwd', stat.S_IROTH)

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod6 <yes> <report> PYTHON_FILE_SEPARATOR_HARDCODED 9528cd
os.chmod('/etc/hosts', 0o700)

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod7 <yes> <report> PYTHON_FILE_SEPARATOR_HARDCODED 9528cd
os.chmod('/etc/hosts', 0o770)

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod9 <yes> <report> PYTHON_FILE_SEPARATOR_HARDCODED 9528cd
os.chmod('/etc/hosts', stat.S_IRWXG)

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod8 <yes> <report> PYTHON_FILE_SEPARATOR_HARDCODED 9528cd
os.chmod('/etc/hosts', stat.S_IRWXU)

# <yes> <report> PYTHON_FILE_PERMISSIONS chmod5
os.chmod(key_file, 0o111)
