

# <yes> <report> PYTHON_BACKDOOR_SPECIAL_ACCOUNT 1c396f
if (login == 'secret_login'):
    # <yes> <report> PYTHON_BACKDOOR_SPECIAL_ACCOUNT 1c396f
    if 'secret password' != self.pswd:
        print ("fail, lol")
    else:
        do_smth_secret()
# <no> <report>
if user_identifier is not None:
    params['UserIdentifier'] = user_identifier
# <no> <report>
if check_password == True:
    do_smth_secret()
# <no> <report>
if (check_password == ''):
    do_smth_secret()
