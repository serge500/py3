from http.cookies import SimpleCookie
from WebKit.HTTPResponse import HTTPResponse
from django.conf import settings
from django.http.response import HttpResponse
from time import time

response = HTTPResponse()
cookie = SimpleCookie()
cookie['foo'] = 'bar'

# <yes> <report> PYTHON_COOKIE_PERSISTENT d69988
cookie['foo']['max-age'] = 901
# <no> <report>
cookie['foo']['max-age'] = 900
# <no> <report>
cookie['foo']['max-age'] = -1

# <yes> <report> PYTHON_COOKIE_PERSISTENT 1lf1kf
SESSION_COOKIE_AGE = 901
# <yes> <report> PYTHON_COOKIE_PERSISTENT kfr1c4
settings.configure(SESSION_COOKIE_AGE=901)


def method5(request, email):
    res = HttpResponse()
    # <yes> <report> PYTHON_COOKIE_PERSISTENT 1er115
    res.set_cookie(
        "emailCookie",
        email,
        expires=time()+901,
        secure=True,
        httponly=True,
        path='/full_path')
    return res
