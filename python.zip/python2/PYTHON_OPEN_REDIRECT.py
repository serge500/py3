from django.shortcuts import redirect
from WebKit.HTTPResponse import HTTPResponse
from WebKit.Page import Page


response = HTTPResponse()
to = 'http://example.com/evil'

# <yes> <report> PYTHON_OPEN_REDIRECT f501be
redirect(to)

# <no> <report>
redirect('http://example.com')

page = Page()

# <yes> <report> PYTHON_OPEN_REDIRECT ef8f15
page.response().sendRedirect(to)

# <yes> <report> PYTHON_OPEN_REDIRECT kd8f14
response.sendRedirect(to)
