import hashlib

# <yes> <report> PYTHON_PASSWORD_NULL c37c10
pwd = None

# <no> <report>
password = p_w_d

# <no> <report>
password = '%s%s' % (pswd1, pswd2)


# <yes> <report> PYTHON_PASSWORD_NULL yuca99
hashlib.pbkdf2_hmac('sha256', None, salt, 100000)

M = poplib.POP3('localhost')


# <yes> <report> PYTHON_PASSWORD_NULL 3j1kqq
M.apop(getpass.getuser(), None)

passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
# <yes> <report> PYTHON_PASSWORD_NULL rj3new
passman.add_password(None, proxy.url, proxy.user, None)
passman2 = urllib2.HTTPPasswordMgr()

# <no> <report>
conn = MySQLdb.connect(_info['hostname'],
                               _info['username'],
                               _info['password'],
                               _info['database'])
