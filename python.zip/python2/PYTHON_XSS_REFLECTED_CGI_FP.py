import os as cgi


def func(item):
    # <yes> <report> PYTHON_INFORMATION_LEAK wedqb9
    print(item)


print("abc")
