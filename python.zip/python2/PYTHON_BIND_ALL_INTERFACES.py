# <yes> <report> PYTHON_BIND_ALL_INTERFACES bind00
s.bind(('0.0.0.0', 31137))
# <yes> <report> PYTHON_BIND_ALL_INTERFACES bind00
s.bind(a = ('0.0.0.0', 31137))
# <no> <report> PYTHON_BIND_ALL_INTERFACES bind00
s.bind("dasd", *('0.0.0.0', 31137))
