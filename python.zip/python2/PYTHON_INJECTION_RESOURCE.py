from MiscUtils.Configurable import Configurable
from django.core.mail import EmailMessage
import builtins
import shelve
import tarfile
import zipfile
import socket
import sys
# <yes> <report> PYTHON_SSL_HOSTNAME_VERIFICATION ef0a72
import urllib
# <yes> <report> PYTHON_SSL_HOSTNAME_VERIFICATION ef0a72
import httplib

config = Configurable()
settingName = 'settingName'

# <yes> <report> PYTHON_INJECTION_RESOURCE 36f5ed
config.setSetting(settingName)

# <yes> <report> PYTHON_INJECTION_RESOURCE 8sf5wd
config.setting(settingName, value)

# <yes> <report> PYTHON_INJECTION_RESOURCE 156b64 <yes> <report> PYTHON_INJECTION_RESOURCE rtec22
open(tempfile.mktemp(), "r+")

file = 'path/to/file'

# <yes> <report> PYTHON_INJECTION_RESOURCE 156b64
open(file)

# <yes> <report> PYTHON_INJECTION_RESOURCE 156b64
setattr(foo, bar, value)

img_data = 'images/img'
message = EmailMessage('Title', 'Body', 'to@example.org')

# <yes> <report> PYTHON_INJECTION_RESOURCE 0afea5
message.attach('design.png', img_data, 'image/png')

# <yes> <report> PYTHON_INJECTION_RESOURCE 0afea5
message.attach('string1', 'string2', arg3)

# <yes> <report> PYTHON_INJECTION_RESOURCE 55142c
shelve.open(file)

# <yes> <report> PYTHON_INJECTION_RESOURCE 62ec63
tarfile.open(file)

# <yes> <report> PYTHON_INJECTION_RESOURCE 62ec63
ZipFile.open(file)

# <yes> <report> PYTHON_INJECTION_RESOURCE c55b0c
zipfile = ZipFile(file)

# <yes> <report> PYTHON_INJECTION_RESOURCE 7a7f80
importlib.import_module(module)

address = sys.stdin.readline()[: - 1]
sock = socket.socket()

# <yes> <report> PYTHON_INJECTION_RESOURCE 799fc7
sock.connect((address, port))

# <yes> <report> PYTHON_INJECTION_RESOURCE 799fc7
sock.connect((address, 1234))

# <yes> <report> PYTHON_INJECTION_RESOURCE 799fc7
socket.connect(address)

# <no> <report>
s.bind(("::1", 0))

url = sys.stdin.readline()[:-1]

# <yes> <report> PYTHON_INJECTION_RESOURCE as04ea
content = urllib.urlopen(url).read()


def test_httplib():
    h = httplib.HTTPConnection('127.0.0.1', 80)
    h.set_debuglevel(1)
    h.putrequest('GET', '/')
    
    # <yes> <report> PYTHON_INJECTION_RESOURCE ds03ef
    h.putheader('Accept', 'text/html')


# <yes> <report> PYTHON_INJECTION_RESOURCE 55ecw1
contents = yaml.load(exploit_file)

# <yes> <report> PYTHON_INJECTION_RESOURCE rtec22
tmp = os.path.join(tempfile.gettempdir(), filename)
