try:
    1 / 0
except ZeroDivisionError:
    c = a + b
else:
    print("Raising generic Error")
    # <yes> <report> PYTHON_ERROR_HANDLING_BROAD_THROW 7a492c
    raise Exception
finally:
    print("In finally block")
    # <no> <report>
    raise NullPointerException
