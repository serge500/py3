from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
import hmac
import stripe

# <yes> <report> PYTHON_CRYPTO_KEY_HARDCODED 8c1e87
key = "7bf651dda432aadd"
# <no> <report>
key = 'key'

k = "not_so_hardcoded"
# <no> <report>
key = k

# <no> <report>
key = bucket.new_key('')

# <no> <report>
full_key = '%s.%s' % (current_prefix, key)

# <no> <report>
newkey = key + '.' + acc + (acc and '.' or '')

# <yes> <report> PYTHON_CRYPTO_KEY_HARDCODED 126e21
cipher = AES.new("7bf651dda432aadd22", AES.MODE_CBC, "iv")


# <yes> <report> PYTHON_CRYPTO_KEY_HARDCODED 226e21
mac = hmac.new("7bf651dda432aadd22", plaintext).hexdigest()

# <yes> <report> PYTHON_CRYPTO_KEY_HARDCODED knte4w
CONSUMER_SECRET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

# <yes> <report> PYTHON_CRYPTO_KEY_HARDCODED bvte43
stripe.api_key = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

# <yes> <report> PYTHON_CRYPTO_KEY_HARDCODED c37c13
token = "7bf651dda432aadd"

key = RSA.generate(2048)
f = open('mykey.pem', 'w')

# <yes> <report> PYTHON_CRYPTO_KEY_HARDCODED mpt77w
f.write(key.exportKey(format='PEM'))

f.close()

# <yes> <report> PYTHON_CRYPTO_KEY_HARDCODED uut7ff
privatekey = key.exportKey(passphrase="code", pkcs=8)















