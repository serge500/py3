# <yes> <report> PYTHON_INJECTION_WILDCARD wldcrd <yes> <report> PYTHON_INJECTION_COMMAND shell1
os.popen('/bin/rsync *')

# <yes> <report> PYTHON_INJECTION_WILDCARD wldcr1 <yes> <report> PYTHON_INJECTION_COMMAND popen2
popen2.popen3('/bin/rsync *')

# <yes> <report> PYTHON_INJECTION_WILDCARD wldcr2
commands.getoutput('/bin/rsync *')

# <yes> <report> PYTHON_INJECTION_WILDCARD wldcr4
subp.Popen('/bin/chown *', shell=True)

# <yes> <report> PYTHON_INJECTION_WILDCARD wldcr5
subp.Popen('/bin/rsync *')

# <yes> <report> PYTHON_INJECTION_WILDCARD wldcr5
subp.Popen('/bin/chmod *')

# <yes> <report> PYTHON_INJECTION_WILDCARD wldcr4
subp.Popen('/bin/tar *', shell=True)

# <yes> <report> PYTHON_INJECTION_WILDCARD wldcr5
subp.Popen('/bin/chown *', shell=False)

# <yes> <report> PYTHON_INJECTION_WILDCARD wldcr5
subp.Popen('/bin/chown *')
