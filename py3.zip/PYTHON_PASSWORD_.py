# <yes> <report> PYTHON_PASSWORD_EMPTY 607f01
password = ""
# <yes> <report> PYTHON_PASSWORD_NULL c37c10
password = None
# <yes> <report> PYTHON_PASSWORD_HARDCODED eed164
password = "hardcoded"
# <yes> <report> PYTHON_PASSWORD_HARDCODED eed164
psswd = "also_hardcoded"

pwd = "not_so_hardcoded"
# <no> <report>
password = pwd